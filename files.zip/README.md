# ResumeAI — Smart Resume Builder

A full-stack-style Resume Builder web application built as a single self-contained HTML file using React 18, Tailwind-inspired CSS, and advanced intelligent features.

## 🚀 How to Run

Simply open `index.html` in any modern browser. No server, no npm install, no build step required.

```
open index.html
```

> Uses CDN-loaded React 18, Babel standalone, jsPDF, and html2canvas.

---

## 📁 Folder Structure (Full-Stack Architecture)

```
resume-builder/
├── index.html               ← Self-contained app (open this!)
├── README.md                ← This file
│
├── frontend/                ← React.js architecture (reference)
│   ├── src/
│   │   ├── components/
│   │   │   ├── Auth/
│   │   │   │   ├── LoginForm.jsx
│   │   │   │   └── SignupForm.jsx
│   │   │   ├── Builder/
│   │   │   │   ├── BasicsForm.jsx
│   │   │   │   ├── ExperienceEditor.jsx
│   │   │   │   ├── EducationEditor.jsx
│   │   │   │   ├── ProjectsEditor.jsx
│   │   │   │   ├── SkillInput.jsx
│   │   │   │   └── CertificationEditor.jsx
│   │   │   ├── Preview/
│   │   │   │   ├── ResumePreview.jsx
│   │   │   │   ├── templates/
│   │   │   │   │   ├── Modern.jsx
│   │   │   │   │   ├── Classic.jsx
│   │   │   │   │   ├── Minimal.jsx
│   │   │   │   │   └── Bold.jsx
│   │   │   ├── Analysis/
│   │   │   │   ├── RealityCheck.jsx
│   │   │   │   ├── JobCustomizer.jsx
│   │   │   │   └── RoastMode.jsx
│   │   │   ├── Import/
│   │   │   │   └── ImportSystem.jsx
│   │   │   └── UI/
│   │   │       ├── Toast.jsx
│   │   │       ├── SkillChip.jsx
│   │   │       └── ScoreRing.jsx
│   │   ├── hooks/
│   │   │   ├── useResume.js
│   │   │   ├── useAuth.js
│   │   │   └── useToast.js
│   │   ├── utils/
│   │   │   ├── parseResume.js     ← Text extraction / heuristic parser
│   │   │   ├── scoreResume.js     ← Strength score algorithm
│   │   │   ├── weakPhrases.js     ← Detection + alternatives
│   │   │   └── pdfExport.js       ← jsPDF / html2canvas wrapper
│   │   ├── App.jsx
│   │   └── index.js
│   ├── tailwind.config.js
│   └── package.json
│
├── backend/                 ← Node.js + Express (reference)
│   ├── src/
│   │   ├── routes/
│   │   │   ├── auth.routes.js     ← POST /api/auth/login, /signup
│   │   │   ├── resume.routes.js   ← CRUD /api/resume
│   │   │   └── upload.routes.js   ← POST /api/upload
│   │   ├── controllers/
│   │   │   ├── auth.controller.js
│   │   │   ├── resume.controller.js
│   │   │   └── upload.controller.js
│   │   ├── models/
│   │   │   ├── User.model.js      ← Mongoose user schema
│   │   │   └── Resume.model.js    ← Mongoose resume schema
│   │   ├── middleware/
│   │   │   ├── auth.middleware.js ← JWT verification
│   │   │   └── upload.middleware.js ← Multer config
│   │   ├── services/
│   │   │   ├── parseService.js    ← pdf-parse + mammoth (DOCX)
│   │   │   └── emailService.js
│   │   └── app.js
│   ├── .env.example
│   └── package.json
│
└── docs/
    ├── api-spec.md
    └── architecture.md
```

---

## ✨ Features Implemented

### Core
- ✅ JWT-based auth (simulated with localStorage)
- ✅ Full resume builder form — Name, Contact, Summary, Skills, Experience, Education, Projects, Certifications
- ✅ Dynamic add/remove entries for all sections
- ✅ Live real-time preview with 4 professional templates (Modern, Classic, Minimal, Bold)
- ✅ PDF export via jsPDF + html2canvas
- ✅ Resume import — upload TXT/PDF, auto-extract and auto-fill fields

### Intelligent Features
- ✅ Reality Check — detects 20+ weak phrases with strong alternatives
- ✅ Resume Strength Score (0–100) with animated breakdown per section
- ✅ Job Customizer — paste JD → skill matching, gap analysis, match % score
- ✅ Roast Mode — brutally honest fun feedback

### UI/UX
- ✅ Dark mode + Light mode toggle
- ✅ Mobile responsive layout
- ✅ Smooth animations throughout
- ✅ Toast notification system
- ✅ Weak phrase highlighting in red
- ✅ Score breakdown with color-coded progress bars

---

## 🔧 Backend Integration (Production)

To connect a real backend:

```js
// auth.routes.js
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user });
});

// upload.routes.js — Multer + pdf-parse
const upload = multer({ dest: 'uploads/' });
router.post('/upload', auth, upload.single('resume'), async (req, res) => {
  const data = await pdfParse(req.file.path);  // or mammoth for .docx
  res.json({ text: data.text });
});
```

## 📦 Dependencies (Backend)

```json
{
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^7.5.0",
    "jsonwebtoken": "^9.0.2",
    "bcryptjs": "^2.4.3",
    "multer": "^1.4.5",
    "pdf-parse": "^1.1.1",
    "mammoth": "^1.6.0",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1"
  }
}
```

---

## 🎨 Templates

| Template | Style |
|----------|-------|
| **Modern** | Purple header, 2-column layout, skill badges |
| **Classic** | Traditional centered header, clean single-column |
| **Minimal** | Ultra-clean, generous whitespace, timeline layout |
| **Bold** | Dark sidebar, accent colors, high contrast |

---

Made with React 18 + CSS Custom Properties + jsPDF
